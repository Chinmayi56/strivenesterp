from datetime import datetime

from sqlalchemy.orm import Session

from app.models.portal import LeaveRequest, LeaveStatus


class AdminLeaveService:

    @staticmethod
    def get_all_leave_requests(db: Session):
        return (
            db.query(LeaveRequest)
            .order_by(LeaveRequest.created_at.desc())
            .all()
        )

    @staticmethod
    def approve_leave(
        db: Session,
        leave_id: str,
        approver_id: str,
    ):
        leave = (
            db.query(LeaveRequest)
            .filter(LeaveRequest.id == leave_id)
            .first()
        )

        if not leave:
            return None

        leave.status = LeaveStatus.APPROVED.value
        leave.approver_id = approver_id
        leave.approval_date = datetime.utcnow()

        db.commit()
        db.refresh(leave)

        return leave

    @staticmethod
    def reject_leave(
        db: Session,
        leave_id: str,
        approver_id: str,
    ):
        leave = (
            db.query(LeaveRequest)
            .filter(LeaveRequest.id == leave_id)
            .first()
        )

        if not leave:
            return None

        leave.status = LeaveStatus.REJECTED.value
        leave.approver_id = approver_id
        leave.approval_date = datetime.utcnow()

        db.commit()
        db.refresh(leave)

        return leave